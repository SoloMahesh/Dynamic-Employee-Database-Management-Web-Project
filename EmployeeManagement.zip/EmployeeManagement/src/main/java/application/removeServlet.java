package application;

import javafiles.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javafiles.EmployeeBOimplement;


@WebServlet("/remove")
public class removeServlet extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		int id = Integer.parseInt(request.getParameter("id"));
		EmployeeBOimplement employeeBO = new EmployeeBOimplement(); 
		int i = employeeBO.delete(id);
		PrintWriter out = response.getWriter();
		if(i==1)
			out.print("<center><b><img src=\"images/tick.png\" height=40px width= 40px>Successfully removed...!");
		else
			out.print("<center><b><img src=\"images/wrongg.png\" height=20px width= 20px>Already removed.Refresh once...!");
		out.print("<br><br><button onclick=\"history.go(-1)\">Back</button></b></center>");
	}
}
