package application;

import javafiles.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javafiles.EmployeeBOimplement;

@WebServlet("/register")
public class registerServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	response.setContentType("text/html");
	int id = Integer.parseInt(request.getParameter("id"));
	String name = request.getParameter("name");
	String email = request.getParameter("email");
	String department = request.getParameter("department");
	int salary = Integer.parseInt(request.getParameter("salary"));
	
	Employee e = new Employee(id,name,email,department,salary);
	EmployeeBOimplement employeeBO = new EmployeeBOimplement(); 
	int i = employeeBO.save(e);
	PrintWriter out = response.getWriter();
	//RequestDispatcher rd = request.getRequestDispatcher("/insert.html");
	//rd.include(request, response);
	if(i==1)
		out.print("<center><b><img src=\"images/tick.png\" height=40px width= 40px>Successfully registered...!");
	else
		out.print("<center><b><img src=\"images/wrongg.png\" height=20px width= 20px>  Id Already available in Database. Refresh & Try with unique id to register...!");
	out.print("<br><br><button onclick=\"history.go(-1)\">Back</button></b></center>");
	}

}


	