package application;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javafiles.EmployeeBOimplement;

@WebServlet("/salaryIncDecServlet")
public class salaryIncDecServlet extends HttpServlet {
	int i;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		int amount = Integer.parseInt(request.getParameter("amount"));
		String option = request.getParameter("option");
		
		EmployeeBOimplement empBO = new EmployeeBOimplement();
		i = empBO.incdec(amount,option);
		empBO.logout();
		PrintWriter out = response.getWriter();
		if(i!=0) {
			out.print("<center><b><img src=\"images/tick.png\" height=40px width= 40px>Salary Updated successfully...!");
		}
		else
			out.print("<center><b><img src=\"images/wrongg.png\" height=30px width= 30px>Salary Not updated...!		");
		out.print("<br><br><button onclick=\"history.go(-1)\">Back</button></b></center>");
			
	}

}
