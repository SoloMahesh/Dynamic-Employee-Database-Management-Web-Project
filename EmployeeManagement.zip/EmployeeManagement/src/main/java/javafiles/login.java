package javafiles;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class login extends HttpServlet {
	private static int count = 2 ;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmployeeBOimplement ebo = new EmployeeBOimplement();
		
		String pass = ebo.getPass();
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		RequestDispatcher rd = request.getRequestDispatcher("/login.html");
		
		if(password.equals(pass) && username.equals("SoloMahesh")) {
			response.sendRedirect("index.html");
		}
		else if(count>0) {
			out.println("<p style=\"color: red;\">"+count-- +" attempts left</p>");
			rd.include(request, response);
		}
		else {
			out.print("<center><b><img src=\"images/block.png\" height=40px width= 40px><h1 style=\"color: red; background-color: chartreuse;\">You are Blocked...!</h1><br></b></center>");
	}

}
}
