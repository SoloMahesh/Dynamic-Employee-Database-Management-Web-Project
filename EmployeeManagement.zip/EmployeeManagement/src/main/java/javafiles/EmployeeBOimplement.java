package javafiles;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmployeeBOimplement implements EmployeeBO {
	
	private static String url = "jdbc:mysql://localhost:3306/jdbcdemo";
	private static String username="root";
	private static String password="root";
	private static Connection connection = null;
	private static PreparedStatement prepareStatement;
	private static Statement createStatement;
	private static ResultSet result;
	
	
	
	private final static String INSERT_QUERY = "INSERT INTO `Employee`(`id`,`name`,`email`,`department`,`salary`) VALUES (?,?,?,?,?)";
	private final static String DELETE_QUERY = "DELETE FROM `Employee` WHERE `id`=?";
	private final static String SELECT_QUERY = "SELECT * FROM `Employee` WHERE `id` = ?";
	private final static String SELECTALL_QUERY = "SELECT * FROM `Employee`";
	private final static String UPDATE_QUERY = "UPDATE `Employee` SET `name` = ?,`email` = ?,`department` = ?, `salary` = ? WHERE `id` = ?";
	private final static String  INC_QUARY = "UPDATE `Employee` SET `salary` = `salary` + ? WHERE `id` > 0";
	private final static String  DEC_QUARY = "UPDATE `Employee` SET `salary` = `salary` - ? WHERE `id` > 0";
	
	
	
	public EmployeeBOimplement() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(url,username,password);
			
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	
	public String getUsername() {
		return username;
	}
	public String getPass() {
		return password;
	}
	
	public int incdec(int amount , String option) {
		try {
			if(option.equals("increment"))
				prepareStatement = connection.prepareStatement(INC_QUARY);
			else
				prepareStatement = connection.prepareStatement(DEC_QUARY);
			prepareStatement.setInt(1,amount);
		
			return prepareStatement.executeUpdate();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}
				return 0;
	}
	
	@Override
	public int save(Employee e) {
		try {
			prepareStatement= connection.prepareStatement(INSERT_QUERY);
			prepareStatement.setInt(1, e.getId());
			prepareStatement.setString(2, e.getName());
			prepareStatement.setString(3, e.getEmail());
			prepareStatement.setString(4, e.getDept());
			prepareStatement.setInt(5, e.getSalary());
			
			return prepareStatement.executeUpdate();
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return 0;
		
		
	}

	@Override
	public int update(Employee e) {
		try {
			prepareStatement = connection.prepareStatement(UPDATE_QUERY);
			prepareStatement.setString(1, e.getName());
			prepareStatement.setString(2, e.getEmail());
			prepareStatement.setString(3, e.getDept());
			prepareStatement.setInt(4, e.getSalary());
			prepareStatement.setInt(5, e.getId());
			return prepareStatement.executeUpdate();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		return 0;
	}

	@Override
	public int delete(int id) {
		
		try {
			prepareStatement = connection.prepareStatement(DELETE_QUERY);
			
			prepareStatement.setInt(1, id);
			
			return prepareStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int deleteAll(Employee e) {
		return delete(e.getId());
	}

	@Override
	public Employee get(int id) {
		try {
			prepareStatement = connection.prepareStatement(SELECT_QUERY);
			prepareStatement.setInt(1, id);
			
			return (Employee) prepareStatement.executeQuery();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<Employee> getAll() {
		ArrayList<Employee> list = new ArrayList<Employee>();
		try {
			createStatement = connection.createStatement();
			result = createStatement.executeQuery(SELECTALL_QUERY);
			
			while(result.next()) {
				int id = result.getInt("id");
				String name = result.getString("name");
				String email = result.getString("email");
				String department = result.getString("department");
				int salary = result.getInt("salary");
				
				Employee e = new Employee(id,name,email,department,salary);
				list.add(e);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public void logout() {
		try {
			connection.close();
			System.gc();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
