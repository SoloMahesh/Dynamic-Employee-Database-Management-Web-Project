package javafiles;

import java.util.List;

public interface EmployeeBO {
	int save(Employee e);
	int update(Employee e);
	int delete(int id);
	int deleteAll(Employee e);
	Employee get(int id);
	List<Employee> getAll();
}
